from flask import Flask, render_template, request
import requests

app = Flask(__name__)

@app.route('/')
def upload():
    return render_template('index.html')
@app.route('/result', methods=['GET', 'POST'])
def userupload():
    ff = request.files['file']
    ff.save(ff.filename)
    key = 'acc_5034359b8a9794a'
    secret = 'be2e5b8607dbd7f85367d891712755ec'
    imc = requests.post('https://api.imagga.com/v2/uploads',
                auth=(key, secret),
                files={'image': open(ff.filename, 'rb')})
    res_post = imc.json()['result']['upload_id']
    imb = requests.get('https://api.imagga.com/v2/tags',
                auth=(key, secret),
                params={'image_upload_id': res_post})
    ima = imb.json()['result']['tags'][0]['tag']['en']
    imb = requests.get('http://api.giphy.com/v1/gifs/search',
                params={'q': ima,'api_key': 'mPJPdlt1GVhzyl8rmxJ3bt2PWSYybdsr'})
    ch = imb.json()['data']
    list = []
    for i in range(0, 10):
        choose = ch[i]['images']['fixed_height']['url']
        list.append(choose)
    return render_template('result.html', choose=tuple(list))
if __name__ == '__main__':
    app.run(debug=True)